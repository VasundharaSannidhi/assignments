# Q3. Write a generator function that yields the next prime number on each iteration.
#
# Sample Input output
#
# Input: 5
# Output: [2, 3, 5, 7, 11]
#
# Input: 10
# Output: [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]

def getPrimeNumbers(inputNum):
    def is_prime(num):
        if num < 2:
            return False
        for index in range(2, int(num ** 0.5) + 1):
            if num % index == 0:
                return False
        return True

    num = 2
    while inputNum > 0:
        if is_prime(num):
            yield num
            inputNum -= 1
        num += 1

# Test the generator function
print(list(getPrimeNumbers(5)))  # [2, 3, 5, 7, 11]
print(list(getPrimeNumbers(10)))  # [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]


