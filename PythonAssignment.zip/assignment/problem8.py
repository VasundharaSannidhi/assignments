# Q8. Write a function that handles the ValueError exception that may be raised when trying to convert a
# string to an integer. The function should prompt the user to enter a new string until a valid integer is entered.
#
# Input: '3'
# Output: 3
#
# Input: 'abc'
# Output: ValueError exception handled, new input prompted

def get_integer_input():
    while True:
        try:
            return int(input("Enter an integer: "))
        except ValueError:
            print("Oops! You missed to enter integer, Please provide integer ")

print(get_integer_input())  # prints the integer input entered by the user

