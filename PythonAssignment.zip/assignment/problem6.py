# Write a function that reads in a CSV file and returns a list of dictionaries,
# where each dictionary represents a row in the CSV file with the keys being the column names
# and the values being the cell values.
#
# Example
#
# Input: CSV file containing the following data:
# id, name, age
# 1, Alice, 20
# 2, Bob, 25
# 3, Charlie, 30
# Output: [{'id': '1', 'name': 'Alice', 'age': '20'},
#          {'id': '2', 'name': 'Bob', 'age': '25'},
#          {'id': '3', 'name': 'Charlie', 'age': '30'}]

import csv

fileName = 'data.csv'
def csv_to_dicts(fileName):
    # Opening file using "with" statement
    with open(fileName, 'r') as data:
        # Use the csv module to read the file
        line = csv.reader(data)
        # Convert the rows to dictionaries and return them as a list
        return list(line)

####### Solution 1:

print(csv_to_dicts(fileName))



########### Solution 2:

with open(fileName, 'r') as data:
  for line in csv.DictReader(data):
      print(line)
      