# Write a function that takes a list of strings and returns a new list with all
# strings that are anagrams of a palindrome (i.e., a word or phrase that can be rearranged to form a palindrome).
# If you can use list comprehension then it will be better.

# Sample Input output
#
# Input: ['racecar', 'hello', 'level', 'carcare', 'carecar', 'civic', 'lehol', 'vicic']
# Output: ['carcare', 'carecar', 'vicic']
#
# Explanation - carecar and carecar are anagrams of a palindrome racecar. vicic is an anagram of palindrome civic.
# lehol is anagram of hello, but hello is not a palindrome, hence lehol is not in the output.

def anagrams_of_palindromes(words):
    def is_anagram_of_palindrome(word):
        # Create a dictionary to count the number of occurrences of each character
        char_counts = {}
        for char in word:
            char_counts[char] = char_counts.get(char, 0) + 1
        # Check if there are more than one odd count in the dictionary
        odd_counts = [count for count in char_counts.values() if count %
                      2 == 1]
        return len(odd_counts) <= 1
    return [word for word in words if is_anagram_of_palindrome(word)]


words = ['racecar', 'hello', 'level', 'carcare',
         'carecar', 'civic', 'lehol', 'vicic']
result = anagrams_of_palindromes(words)
print(result)