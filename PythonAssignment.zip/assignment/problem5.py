# Q5. Write a function or lambda function (preferably) that takes a list of strings and returns a new list
# with all strings sorted in descending order of length.
#
# Input: ["dog", "cat", "bird"]
# Output: ['bird', 'cat', 'dog']
#
# Input: ["python", "java", "c++"]
# Output: ["python", "java", "c++"]

# Solution 1:
def sort_by_length(strings): return sorted(strings, key=lambda string: -len(string))
stringsList = ["python", "c++", "java", "mysql"]
print(sort_by_length(stringsList))  # ["python", "java", "c++"]

# Solution 2:
strings = ["Sort", "python", "descending", "order", "program"]
print(sorted(strings, key=lambda string: len(string), reverse=True))

