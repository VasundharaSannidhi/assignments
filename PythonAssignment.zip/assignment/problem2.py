# Write a decorator that measures the execution time of a function and logs the result to a file.

import time

def log_execution_time(func):
    def wrapper(*args, **kwargs):
        startTime = time.time()
        result = func(*args, **kwargs)
        endTime = time.time()
        totalExecutionTime = endTime - startTime

        with open('execution_times.log', 'a') as f:
            f.write(f'{func.__name__}: {totalExecutionTime}\n')

        return result
    return wrapper

# sample function to test time of execution

@log_execution_time
def log_execution_function():
    time.sleep(4)

# sample function to test time of execution

@log_execution_time
def addNumbersTillGivenNumber(num):
    total = sum((x for x in range(0, num)))
    return total

print(addNumbersTillGivenNumber(30))

log_execution_function()
